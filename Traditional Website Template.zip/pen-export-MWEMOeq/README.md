# Traditional Website Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/Delos_343/pen/MWEMOeq](https://codepen.io/Delos_343/pen/MWEMOeq).

